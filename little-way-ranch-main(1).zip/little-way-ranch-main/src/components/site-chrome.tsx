import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import logo from "@/assets/logo.png.asset.json";

const links = [
  { to: "/", label: "Home" },
  { to: "/shop", label: "Shop" },
  { to: "/faq", label: "FAQ" },
  { to: "/contact", label: "Contact" },
] as const;

export function Divider() {
  return (
    <div className="flex items-center justify-center gap-3 text-accent" aria-hidden>
      <span className="h-px w-12 bg-border" />
      <span className="text-xs">✦</span>
      <span className="h-px w-12 bg-border" />
    </div>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
        <Link to="/" className="flex items-center gap-2" onClick={() => setOpen(false)}>
          <img src={logo.url} alt="Little Way Baby" className="h-14 w-auto" />
        </Link>
        <nav className="hidden gap-8 md:flex">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              activeOptions={{ exact: true }}
              className="text-xs uppercase tracking-[0.25em] text-muted-foreground transition-colors hover:text-foreground"
              activeProps={{ className: "text-foreground border-b border-accent pb-1" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav className="flex flex-col border-t border-border md:hidden">
          {links.map((l) => (
            <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="px-6 py-4 text-xs uppercase tracking-[0.25em]">
              {l.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 py-14 md:grid-cols-3">
        <div>
          <p className="font-display text-2xl tracking-widest">LITTLE WAY</p>
          <p className="mt-1 text-xs uppercase tracking-[0.4em] text-accent">Baby</p>
          <p className="mt-4 text-sm opacity-70">Little things for little ones. Est. 2026.</p>
        </div>
        <div className="flex flex-col gap-2 text-sm">
          {links.map((l) => (
            <Link key={l.to} to={l.to} className="opacity-70 hover:opacity-100">{l.label}</Link>
          ))}
        </div>
        <div className="text-sm opacity-70">
          <p>littlewaybaby@gmail.com</p>
          <p className="mt-2 text-xs">
            <a href="https://instagram.com/littlewaybaby" target="_blank" rel="noreferrer" className="underline underline-offset-4 hover:opacity-100">Instagram</a>
            {" · "}
            <a href="https://facebook.com/littlewaybaby" target="_blank" rel="noreferrer" className="underline underline-offset-4 hover:opacity-100">Facebook</a>
            {" — @littlewaybaby"}
          </p>
          <p className="mt-6 text-xs">© 2026 Little Way Baby</p>
        </div>
      </div>
    </footer>
  );
}
