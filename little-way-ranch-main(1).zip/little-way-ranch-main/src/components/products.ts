export type Colorway = { name: string; css: string };

const COW_PRINT =
  "radial-gradient(circle at 30% 30%, #2b2622 20%, transparent 21%), radial-gradient(circle at 68% 58%, #2b2622 16%, transparent 17%), radial-gradient(circle at 52% 18%, #2b2622 10%, transparent 11%), #f2ede4";

const DUSTY_PINK = "#d9a9a4";
const BEIGE = "#e8dfce";
const DARK_BROWN = "#4e3b2e";
const LIGHT_BROWN = "#b99b72";
const DUSTY_BLUE = "#a7b8c6";
const SAGE_GREEN = "#a9b2a0";

type Product = {
  name: string;
  priceLabel: string;
  desc: string;
  colors: Colorway[];
};

export const products: Product[] = [
  {
    name: "The Cowgirl",
    priceLabel: "$12 silver · $13 wooden",
    desc: "Dusty pink, beige, dark brown and cow print — for the little lady of the house.",
    colors: [
      { name: "Dusty Pink", css: DUSTY_PINK },
      { name: "Beige", css: BEIGE },
      { name: "Dark Brown", css: DARK_BROWN },
      { name: "Cow Print", css: COW_PRINT },
    ],
  },
  {
    name: "The Cowboy",
    priceLabel: "$12 silver · $13 wooden",
    desc: "Dusty blue, beige and light brown — a good, quiet kind of handsome.",
    colors: [
      { name: "Dusty Blue", css: DUSTY_BLUE },
      { name: "Beige", css: BEIGE },
      { name: "Light Brown", css: LIGHT_BROWN },
    ],
  },
  {
    name: "The Wildflower",
    priceLabel: "$12 silver · $13 wooden",
    desc: "Dusty pink, beige and sage green — picked straight from the meadow.",
    colors: [
      { name: "Dusty Pink", css: DUSTY_PINK },
      { name: "Beige", css: BEIGE },
      { name: "Sage Green", css: SAGE_GREEN },
    ],
  },
  {
    name: "Personalized",
    priceLabel: "$15",
    desc: "Your little one's name on any colorway. Tell us the name and colors when you order.",
    colors: [
      { name: "Cow Print", css: COW_PRINT },
      { name: "Beige", css: BEIGE },
      { name: "Light Brown", css: LIGHT_BROWN },
      { name: "Dark Brown", css: DARK_BROWN },
    ],
  },
];
