import { Divider } from "./site-chrome";

export function PageTitle({ kicker, title, sub }: { kicker: string; title: string; sub?: string }) {
  return (
    <div className="border-b border-border bg-secondary px-6 py-16 text-center">
      <p className="text-xs uppercase tracking-[0.4em] text-muted-foreground">{kicker}</p>
      <h1 className="mt-3 font-display text-3xl md:text-4xl tracking-wider">{title}</h1>
      <div className="mt-5"><Divider /></div>
      {sub && <p className="mx-auto mt-5 max-w-xl text-muted-foreground">{sub}</p>}
    </div>
  );
}
