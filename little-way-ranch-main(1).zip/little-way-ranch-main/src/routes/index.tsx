import { createFileRoute, Link } from "@tanstack/react-router";
import { products } from "@/components/products";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Little Way Baby — Vintage Western Pacifier Clips" },
      { name: "description", content: "Handmade western-inspired pacifier clips that keep your little one's pacifier close and clean." },
      { property: "og:title", content: "Little Way Baby — Vintage Western Pacifier Clips" },
      { property: "og:description", content: "Pacifier clips, made by hand." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <>
      <section className="flex min-h-[60vh] items-center justify-center bg-primary px-6 text-center text-primary-foreground">
        <div>
          <h1 className="font-display text-4xl md:text-6xl tracking-widest">LITTLE WAY</h1>
          <p className="mt-2 text-sm uppercase tracking-[0.6em]">Baby</p>
          <p className="mt-6">Pacifier clips</p>
          <Link to="/shop" className="mt-8 inline-block border border-primary-foreground px-8 py-3 text-xs uppercase tracking-[0.3em] transition-colors hover:bg-primary-foreground hover:text-primary">Shop</Link>
        </div>
      </section>

      <section className="bg-secondary py-20">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="text-center font-display text-3xl tracking-wider">The Collection</h2>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {products.slice(0, 3).map((p) => (
              <div key={p.name} className="border border-border bg-card p-8 text-center transition-transform hover:-translate-y-1">
                <h3 className="font-display tracking-wider">{p.name}</h3>
                <p className="mt-3 text-sm text-muted-foreground">{p.desc}</p>
                <p className="mt-4 text-accent">{p.priceLabel}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 text-center">
            <Link to="/shop" className="text-xs uppercase tracking-[0.3em] border-b border-foreground pb-1">View all</Link>
          </div>
        </div>
      </section>
    </>
  );
}
