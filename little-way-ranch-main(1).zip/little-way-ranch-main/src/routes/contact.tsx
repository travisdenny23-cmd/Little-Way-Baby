import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageTitle } from "@/components/page-title";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Little Way Baby" },
      { name: "description", content: "Get in touch with Little Way Baby for orders and questions." },
      { property: "og:title", content: "Contact — Little Way Baby" },
      { property: "og:description", content: "Send us a note about orders, custom clips or anything else." },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = useState(false);
  const field = "w-full border border-input bg-card px-4 py-3 outline-none focus:border-foreground";
  return (
    <>
      <PageTitle kicker="Send Word" title="Contact" sub="Questions, orders or custom requests — we'd love to hear from you." />
      <div className="mx-auto max-w-xl px-6 py-16">
        {sent ? (
          <p className="text-center font-display text-xl tracking-wider">Thank you — we'll be in touch soon.</p>
        ) : (
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); setSent(true); }}>
            <input required placeholder="Name" className={field} />
            <input required type="email" placeholder="Email" className={field} />
            <textarea required rows={5} placeholder="Message" className={field} />
            <button className="w-full bg-primary py-3 text-xs uppercase tracking-[0.3em] text-primary-foreground hover:opacity-80">Send</button>
          </form>
        )}
        <div className="mt-10 text-center text-sm text-muted-foreground">
          <p>littlewaybaby@gmail.com</p>
          <p className="mt-2">
            <a href="https://instagram.com/littlewaybaby" target="_blank" rel="noreferrer" className="underline underline-offset-4 hover:text-foreground">Instagram</a>
            {" · "}
            <a href="https://facebook.com/littlewaybaby" target="_blank" rel="noreferrer" className="underline underline-offset-4 hover:text-foreground">Facebook</a>
            {" — @littlewaybaby"}
          </p>
        </div>
      </div>
    </>
  );
}
