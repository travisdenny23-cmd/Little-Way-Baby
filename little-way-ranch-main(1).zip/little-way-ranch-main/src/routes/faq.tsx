import { createFileRoute } from "@tanstack/react-router";
import { PageTitle } from "@/components/page-title";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Little Way Baby" },
      { name: "description", content: "Answers about our pacifier clips, safety, care and shipping." },
      { property: "og:title", content: "FAQ — Little Way Baby" },
      { property: "og:description", content: "Common questions about Little Way Baby pacifier clips." },
    ],
  }),
  component: Faq,
});

const faqs: [string, string][] = [
  ["Will the clip fit any pacifier?", "Yes — the loop fits most pacifiers, teethers and small toys with a handle or ring."],
  ["Is it safe for my baby?", "Yes. Just keep an eye on your little one while they're wearing it."],
  ["How do I clean it?", "Wipe it with a damp rag."],
  ["How long does shipping take?", "Shipping depends on your location. Send us a message and we'll give you an estimate."],
  ["Can I return a clip?", "All sales are final — no refunds."],
];

function Faq() {
  return (
    <>
      <PageTitle kicker="Questions" title="FAQ" />
      <div className="mx-auto max-w-2xl px-6 py-16">
        <Accordion type="single" collapsible>
          {faqs.map(([q, a]) => (
            <AccordionItem key={q} value={q}>
              <AccordionTrigger className="text-base">{q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </>
  );
}
