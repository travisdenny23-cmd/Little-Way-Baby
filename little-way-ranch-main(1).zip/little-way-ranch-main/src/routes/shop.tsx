import { createFileRoute, Link } from "@tanstack/react-router";
import { PageTitle } from "@/components/page-title";
import { products } from "@/components/products";

export const Route = createFileRoute("/shop")({
  head: () => ({
    meta: [
      { title: "Shop Pacifier Clips — Little Way Baby" },
      { name: "description", content: "Browse our full line of western-style pacifier clips." },
      { property: "og:title", content: "Shop Pacifier Clips — Little Way Baby" },
      { property: "og:description", content: "Leather, wood and silicone pacifier clips with vintage western style." },
    ],
  }),
  component: Shop,
});

function Shop() {
  return (
    <>
      <PageTitle kicker="The General Store" title="Shop" sub="Every clip is made to hold tight and look sharp." />
      <div className="mx-auto grid max-w-6xl gap-6 px-6 py-16 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((p) => (
          <div key={p.name} className="flex flex-col border border-border bg-card p-8 transition-shadow hover:shadow-lg">
            <div className="flex aspect-square items-center justify-center gap-3 bg-secondary px-6">
              {p.colors.map((c) => (
                <span
                  key={c.name}
                  title={c.name}
                  aria-label={c.name}
                  className="h-8 w-8 shrink-0 rounded-full border border-border shadow-sm"
                  style={{ background: c.css }}
                />
              ))}
            </div>
            <h3 className="mt-6 font-display tracking-wider">{p.name}</h3>
            <p className="mt-2 flex-1 text-sm text-muted-foreground">{p.desc}</p>
            <p className="mt-3 text-xs uppercase tracking-[0.2em] text-muted-foreground">
              {p.colors.map((c) => c.name).join(" · ")}
            </p>
            <div className="mt-4 flex items-center justify-between">
              <span className="text-lg">{p.priceLabel}</span>
              <Link to="/contact" className="bg-primary px-5 py-2 text-xs uppercase tracking-[0.2em] text-primary-foreground hover:opacity-80">Order</Link>
            </div>
          </div>
        ))}
      </div>
      <p className="mx-auto max-w-2xl px-6 pb-16 text-center text-sm text-muted-foreground">
        Clips are $12 with a silver clip or $13 with a wooden clip. Personalized requests are $15 — just mention the name and colors you'd like when you order.
      </p>
    </>
  );
}
